package pacman;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class test {
	game ga;
	field map;
	
	@BeforeEach 
	public void setUp() {
    this.ga=new game();
    this.map=new field(ga.frame);
    
    
	 }

	 @Test
	 public void testfield() {	
	this.map.setemptylocations();
	this.map.setmap();
	Assert.assertEquals(map.avatar.pac_x, 13, 0);
	Assert.assertEquals(map.avatar.pac_y, 19, 0);
	Assert.assertEquals(map.redmonster.monster_x, 2, 0);
	Assert.assertEquals(map.redmonster.monster_y, 1, 0);
	Assert.assertEquals(map.bluemonster.monster_x, 13, 0);
	Assert.assertEquals(map.bluemonster.monster_y, 1, 0);
	Assert.assertEquals(map.orangemonster.monster_x, 2, 0);
	Assert.assertEquals(map.orangemonster.monster_y, 19, 0);
	Assert.assertEquals(map.pinkmonster.monster_x, 3, 0);
	Assert.assertEquals(map.pinkmonster.monster_y, 10, 0);



	 }
	
	 @Test
	 public void testscore() {	
	int x1=map.avatar.score_check(0);
	int x2=map.avatar.score_check(20);
	Assert.assertEquals(x1, 1, 0);
	Assert.assertEquals(x2, 0, 0);
	 }
	 @Test
	 public void testeatpac() {
		this.map.setemptylocations();
		this.map.setmap();
		 map.avatar.pac_x=11;
		 map.avatar.pac_y=17;
		 map.f[map.avatar.pac_x][map.avatar.pac_y].setIcon(map.avatar.pacmanup);
		int x=map.avatar.life-1;
		map.redmonster.monster_x=map.avatar.pac_x-1;
		map.redmonster.monster_y=map.avatar.pac_y;
		 map.redmonster.check(0);
		 Assert.assertEquals(x, map.avatar.life, 0);
		 map.avatar.life++;
		 map.redmonster.monster_x=map.avatar.pac_x+1;
		 map.redmonster.check(1);
		 Assert.assertEquals(x, map.avatar.life, 0);
		 map.avatar.life++;
		 map.redmonster.monster_x=map.avatar.pac_x;
		 map.redmonster.monster_y=map.avatar.pac_y-1;
		 map.redmonster.check(2);
		 Assert.assertEquals(x, map.avatar.life, 0);
		 map.avatar.life++;
		 map.redmonster.monster_x=map.avatar.pac_x;
		 map.redmonster.monster_y=map.avatar.pac_y+1;
		 map.redmonster.check(3);
		 Assert.assertEquals(x, map.avatar.life, 0);
		 map.avatar.life++;

	 }
	 
}
