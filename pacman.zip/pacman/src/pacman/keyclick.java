package pacman;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class keyclick extends KeyAdapter {
	pac avatar;
	public keyclick(pac avatar) {this.avatar=avatar;}
	@Override
	public void keyPressed(KeyEvent e) {
		int key = e.getKeyCode();
         switch(key) {
		
		case KeyEvent.VK_UP:
			avatar.mouve=1;
			break;	
		case KeyEvent.VK_DOWN:
			avatar.mouve=2;
			break;
		case KeyEvent.VK_LEFT:
			avatar.mouve=3;
			break;
		case KeyEvent.VK_RIGHT:
			avatar.mouve=4;
		
	}

		}
	
	

}
