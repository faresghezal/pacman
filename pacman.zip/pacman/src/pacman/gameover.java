package pacman;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class gameover {
	public gameover(field field){
		
		    field.panel.setVisible(false);
		    field.panel.removeAll();
		    JPanel game_over = new JPanel();
		    game_over.setLayout(null);
		    JButton endImg = new JButton(new ImageIcon("gameover.png"));
		    endImg.setBackground(Color.black);
		    endImg.setBounds(120, 100, 735, 173);
		    endImg.setBorderPainted(false);
		    endImg.setFocusPainted(false);
			game_over.add(endImg);
			JTextField textfield = new JTextField();
			textfield.setBounds(530,300,170,50);
			game_over.add(textfield);
			
			game_over.setPreferredSize(new Dimension(1000, 600));
			game_over.setBackground(Color.black);
			
			JButton name = new JButton(new ImageIcon("name.png"));
			name.setBackground(Color.black);
			name.setBounds(380, 300, 150, 50);
			name.setBorderPainted(false);
			name.setFocusPainted(false);
			game_over.add(name);
			
			JButton insert = new JButton(new ImageIcon("insert.png"));
			insert.setBackground(Color.black);
			insert.setBounds(400, 400, 244, 60);
			insert.setBorderPainted(false);
			insert.setFocusPainted(false);
			game_over.add(insert);		
			field.frame.add(game_over);
			field.frame.pack();
			field.frame.setVisible(true);
			insert.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent arg0) {
	            	String s=textfield.getText();
	            	serilazation ser=new serilazation();
	            	try {
						ser.output(s,field.avatar.score);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
	            	field.frame.dispose();
	              }
	            });
	}

}
