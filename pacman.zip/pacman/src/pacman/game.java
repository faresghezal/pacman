package pacman;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class game extends JPanel {
	JFrame frame;
	public game() {
		 this.frame = new JFrame();
			this.frame.setTitle("fares pacman");
	        JPanel start = new JPanel() {	
				@Override
				public void setBackground(Color bg) {
					// TODO Auto-generated method stub
					super.setBackground(Color.black);
				}
			};
			
			JButton startImg = new JButton(new ImageIcon("pacmantitle.png"));
			startImg.setBackground(Color.black);
			startImg.setBounds(120, 100, 735, 173);
			startImg.setBorderPainted(false);
			startImg.setFocusPainted(false);
			start.add(startImg);
			start.setLayout(null);
			start.setPreferredSize(new Dimension(1000, 600));
			JButton startButton = new JButton(new ImageIcon("start.png"));
			startButton.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent arg0) {
	              start.setVisible(false);
	              field map=new field(frame);
	              map.startgame();
	              }
	            });
			startButton.setBackground(Color.black);
			startButton.setBorderPainted(false);
			startButton.setFocusPainted(false);
			startButton.setBounds(410, 300, 166, 40);
	        start.add(startButton);
			JButton scoreButton = new JButton(new ImageIcon("score.png"));
			scoreButton.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent arg0) {
	              start.setVisible(false);
	              start.removeAll();
	              String[][]score = new String[2][];
	              serilazation ser=new serilazation();
	              try {
	            	  score=ser.input();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
                    String column[]={"name","score"};         
                    JTable jt=new JTable(score,column);             
                    JScrollPane sp=new JScrollPane(jt); 
                    sp.setPreferredSize(new Dimension(800, 600));
        		    JPanel scorepanel = new JPanel();
        		    scorepanel.add(sp);
        		    scorepanel.setPreferredSize(new Dimension(1000, 600));
        		    scorepanel.setBackground(Color.black);
        		    frame.add(scorepanel);
        		    frame.setVisible(true);
	              
	              
	              
	              }
	            });
	        scoreButton.setBackground(Color.black);
	        scoreButton.setBorderPainted(false);
	        scoreButton.setFocusPainted(false);
	        scoreButton.setBounds(409, 380, 166, 40);
	        start.add(scoreButton);
			JButton exitButton = new JButton(new ImageIcon("exit.png"));
			exitButton.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent arg0) {
	              start.setVisible(false);
	              frame.dispose();
	              }
	            });
			exitButton.setBackground(Color.black);
			exitButton.setBorderPainted(false);
			exitButton.setFocusPainted(false);
			exitButton.setBounds(409, 460, 166, 40);
	        start.add(exitButton);
			frame.add(start);
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

			Toolkit toolkit = frame.getToolkit();
			Image image = toolkit.createImage("pacmanright.png");
			this.frame.setIconImage(image);
			this.frame.pack();
			this.frame.setVisible(true);
		
	}
	public static void main(String[] args) {
		
		game start=new game();

	}

}
