package pacman;

import javax.swing.ImageIcon;

public class blinky extends monster {
	public blinky(pac pacman,field field ,int x,int y) {
		super.pacman=pacman;
		super.field=field;
		super.enemy = new ImageIcon("redenemy.png");
		super.monster_x=x;
		super.monster_y=y;
	}


}
