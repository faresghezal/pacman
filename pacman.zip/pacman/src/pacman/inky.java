package pacman;

import javax.swing.ImageIcon;

public class inky extends monster {
	public inky(pac pacman,field field,int x,int y) {
		super.pacman=pacman;
		super.field=field;
		super.enemy = new ImageIcon("blueenemy.png");
		super.monster_x=x;
		super.monster_y=y;
		
	}

}
