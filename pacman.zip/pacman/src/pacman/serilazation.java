package pacman;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonWriter;
public class serilazation{

     public void output(String s,int n)throws  IOException {
		n=n*10;
		Integer i = n;
		JsonObject value =Json.createObjectBuilder().add("name", s).add("score", i.toString()).build();
		FileWriter file = new FileWriter("score.json", true);
		JsonWriter w = Json.createWriter(file);
		JsonObject o = value;
		w.writeObject(o);
		file.write("\n");
		w.close();
		return;
	


	}
	public String[][] input() throws IOException {
		String[][] result = new String[100][2];
		int i=0;
		FileReader file = null;
		String line= null;
			file = new FileReader("score.json");
		BufferedReader bufferedReader = new BufferedReader(file);
		JsonReader reader = Json.createReader(bufferedReader);
		while(((line = bufferedReader.readLine()) != null)&&(i<100)) {
		JsonReader jsonReader = Json.createReader(new StringReader(line));
		JsonObject obj = jsonReader.readObject();
		String name = obj.getString("name");
		String score = obj.getString("score");
		result[i][0]=name;
		result[i][1]=score;
		i++;
		}
		reader.close();
		return result;

	}

}