package pacman;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class pac extends Thread {
	public int pac_x,pac_y;
	public int score;
	int life=3;
	int mouve=0;
	int n=100;
	field field;
	ImageIcon pacmanleft ;
	ImageIcon pacmanright;
	ImageIcon pacmanup;
	ImageIcon pacmandown;
	ImageIcon one;
	ImageIcon two ;
	ImageIcon three;
	ImageIcon four;
	ImageIcon five;
	ImageIcon six ;
	ImageIcon seven;
	ImageIcon eight;
	ImageIcon nine;
	ImageIcon zero ;

	public pac(int x,int y,field field) {
		this.pac_x=x;
		this.pac_y=y;
		this.field=field;
		this.pacmanleft = new ImageIcon("pacmanleft.png");
		this.pacmanright = new ImageIcon("pacmanright.png");
		this.pacmanup = new ImageIcon("pacmanup.png");
		this.pacmandown = new ImageIcon("pacmandown.png");
		this. one = new ImageIcon("one.png");
		this. two = new ImageIcon("two.png");
		this. three = new ImageIcon("three.png");
		this. four = new ImageIcon("four.png");
		this. five = new ImageIcon("five.png");
		this. six = new ImageIcon("six.png");
		this. seven = new ImageIcon("seven.png");
		this. eight = new ImageIcon("eight.png");
		this. nine = new ImageIcon("nine.png");
		this. zero = new ImageIcon("zero.png");
		
	}
	public void showscore(int score) {
				
				int location,score2;
				if(score/10>=10) {
					location=1;
				}
				else if(score/10!=0) {
					location = 2;
				}
				else {
					location = 3;
				}
				
				while(location<=3) {
				if(location==1)
					score2=score/100;
					
					else if(location ==2)
						score2= score/10%10;
					else
						score2 = score%10;
				switch(score2) {
				case 0:
					field.f[0][location].setIcon(zero); break;
				case 1:
					field.f[0][location].setIcon(one); break;
				case 2:
					field.f[0][location].setIcon(two); break;
				case 3:
					field.f[0][location].setIcon(three); break;
				case 4:
					field.f[0][location].setIcon(four); break;
				case 5:
					field.f[0][location].setIcon(five); break;
				case 6:
					field.f[0][location].setIcon(six); break;
				case 7:
					field.f[0][location].setIcon(seven); break;
				case 8:
					field.f[0][location].setIcon(eight); break;
				case 9:
					field.f[0][location].setIcon(nine); break;
				}
				location++;
				}
				field.f[0][4].setIcon(zero);
				
			}
	public int score_check(int pellet) {
			if(pellet==0) {
				this.n=this.n-10;
				this.mouve=0;
				field.redmonster.n=field.redmonster.n-10;
				field.pinkmonster.n=field.pinkmonster.n-10;
				field.bluemonster.n=field.bluemonster.n-10;
				field.orangemonster.n=field.orangemonster.n-10;
				field.redmonster.real_location_save=0;
				field.pinkmonster.real_location_save=0;
				field.bluemonster.real_location_save=0;
				field.orangemonster.real_location_save=0;
				this.life=3;
			    field.panel.setVisible(false);
			    field.panel.removeAll();
				field.panel = new JPanel();
				field.panel.setPreferredSize(new Dimension(1000, 600));
				field.panel.setBackground(Color.black);
				field.panel.setLayout(new GridLayout(field.f.length,field.f[0].length));
				field.frame.requestFocus();
				field.setemptylocations();
				field.setmap();
				field.frame.pack();
				field.frame.setVisible(true);
				return 1;
				
             }
			else return 0;
     }	
	
	
	
	public void run() {
		while(true) {
		switch(mouve) {
		case 1:{
			if(mouve !=1||(field.f[pac_x-1][pac_y].getIcon()).equals(field.wall)||pac_x==1){
			}
			else {	
			if((field.f[pac_x-1][pac_y].getIcon()).equals(field.empty)||(field.f[pac_x-1][pac_y].getIcon()).equals(field.pellet)) {
				
				if((field.f[pac_x-1][pac_y].getIcon()).equals(field.pellet)) {
					score++;
					field.pelletnumber--;
					showscore(score);
					
				}
				field.f[pac_x][pac_y].setIcon(field.empty);
				pac_x--;
				field.f[pac_x][pac_y].setIcon(pacmanup);
				score_check(field.pelletnumber);
			
		}
			mouve =0;
			}
			
			
		}
		break;
		case 2:
			if(mouve !=2||(field.f[pac_x+1][pac_y].getIcon()).equals(field.wall)){

			}
			
			else {
				
			if((field.f[pac_x+1][pac_y].getIcon()).equals(field.empty)||(field.f[pac_x+1][pac_y].getIcon()).equals(field.pellet)) {
				if((field.f[pac_x+1][pac_y].getIcon()).equals(field.pellet)) {
					score++;
					field.pelletnumber--;
					showscore(score);
					
				}
				field.f[pac_x][pac_y].setIcon(field.empty);
				pac_x++;
				field.f[pac_x][pac_y].setIcon(pacmandown);
				score_check(field.pelletnumber);
		}
			
			mouve=0;
			}
		break;
		case 3:
			
			if(mouve !=3||(field.f[pac_x][pac_y-1].getIcon()).equals(field.wall)){}
	
		else {
			
		if((field.f[pac_x][pac_y-1].getIcon()).equals(field.empty)||(field.f[pac_x][pac_y-1].getIcon()).equals(field.pellet)) {
			if((field.f[pac_x][pac_y-1].getIcon()).equals(field.pellet)) {
				score++;
				field.pelletnumber--;
				showscore(score);
			}
			field.f[pac_x][pac_y].setIcon(field.empty);
			pac_y--;
			field.f[pac_x][pac_y].setIcon(pacmanleft);
			score_check(field.pelletnumber);
	}
		
		mouve=0;
		}
	break;
	case 4:
		if(mouve !=4||(field.f[pac_x][pac_y+1].getIcon()).equals(field.wall)){
		}
		else {
			
		if((field.f[pac_x][pac_y+1].getIcon()).equals(field.empty)||(field.f[pac_x][pac_y+1].getIcon()).equals(field.pellet)) {
			if((field.f[pac_x][pac_y+1].getIcon()).equals(field.pellet)) {
				score++;
				field.pelletnumber--;
				showscore(score);
				
			}
			field.f[pac_x][pac_y].setIcon(field.empty);
			pac_y++;
			field.f[pac_x][pac_y].setIcon(pacmanright);
			score_check(field.pelletnumber);
	}
		
		mouve=0;
		}
		break;
		
             }
		try {
			sleep(n);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }}
}