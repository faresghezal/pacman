package pacman;

import javax.swing.ImageIcon;

public class pinkey extends monster {
	public pinkey(pac pacman,field field ,int x,int y) {
		super.pacman=pacman;
		super.field=field;
		super.enemy = new ImageIcon("pinkenemy.png");
		super.monster_x=x;
		super.monster_y=y;
		
	}

}
