package pacman;

import javax.swing.ImageIcon;

public class clyde extends monster {
	public clyde(pac pacman,field field,int x,int y) {
		super.pacman=pacman;
		super.field=field;
		super.enemy = new ImageIcon("orangeenemy.png");
		super.monster_x=x;
		super.monster_y=y;
		
	}

}
