package pacman;
import javax.swing.ImageIcon;


public class monster  extends Thread {
	int monster_x,monster_y;
	ImageIcon enemy;
	int enemy_location[][] = {{1,0},{-1,0},{0,1},{0,-1}};
	int location_save=0;
	int real_location_save=0;
	int n=200;
	
    pac pacman;
    field field;
    public void check(int random) {
    	if((field.f[monster_x+enemy_location[random][0]][monster_y+enemy_location[random][1]].getIcon()).equals(pacman.pacmanright)||(field.f[monster_x+enemy_location[random][0]][monster_y+enemy_location[random][1]].getIcon()).equals(pacman.pacmanleft)||(field.f[monster_x+enemy_location[random][0]][monster_y+enemy_location[random][1]].getIcon()).equals(pacman.pacmanup)||(field.f[monster_x+enemy_location[random][0]][monster_y+enemy_location[random][1]].getIcon()).equals(pacman.pacmandown)) {
			switch(pacman.life) {
			case 3: 
				--pacman.life;
				field.f[0][18].setIcon(field.empty);
				break;
			
			case 2: 
				--pacman.life;
				field.f[0][19].setIcon(field.empty);
				break;
			case 1: 
				field.f[0][20].setIcon(field.empty);
				--pacman.life;
				break;
			case 0: 
				--pacman.life;
				break;
			}
		}
		
		if(pacman.life ==0) {
			gameover end=new gameover(field);
		}
  		
    }
 	public void run() {
 		while(true) {
		int random = (int)(Math.random()*4);
		int random2 = (int)(Math.random()*4);
		
		this.check(random2);
		//not get out of bound or in a wall
			while(monster_x+enemy_location[random][0]>=2&&monster_x+enemy_location[random][0]<=11&&monster_y+enemy_location[random][1]>=1&&monster_y+enemy_location[random][1]>=20) 
      			random = (int)(Math.random()*4);   		
			while(!((field.f[monster_x+enemy_location[random][0]][monster_y+enemy_location[random][1]].getIcon()).equals(field.empty)||(field.f[monster_x+enemy_location[random][0]][monster_y+enemy_location[random][1]].getIcon()).equals(field.pellet))) 
      			random = (int)(Math.random()*4);	
			//restore pellet after going through their space
      		if((field.f[monster_x+enemy_location[random][0]][monster_y+enemy_location[random][1]].getIcon()).equals(field.empty))
      			location_save = 1;	
      		else if((field.f[monster_x+enemy_location[random][0]][monster_y+enemy_location[random][1]].getIcon()).equals(field.pellet))
      			location_save=0;
      		     
     		//the actuall mouvment
      		switch(real_location_save) {
      		case 0:field.f[monster_x][monster_y].setIcon(field.pellet);break;
      		case 1:field.f[monster_x][monster_y].setIcon(field.empty);break;
      		}
      		real_location_save=location_save;
      		monster_x+=enemy_location[random][0];
      		monster_y+=enemy_location[random][1];
      		
      		field.f[monster_x][monster_y].setIcon(enemy);
      		
    		try {
    			Thread.sleep(n);
    		} catch (InterruptedException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}

 		}
		}

	}


