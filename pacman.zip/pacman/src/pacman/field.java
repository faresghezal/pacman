package pacman;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class field {
	JLabel[][] f = new JLabel[15][21];
	JPanel panel;
	int[][] maplocation;
	JFrame frame;
	int pelletnumber;
	ImageIcon wall ;
	ImageIcon empty;
	ImageIcon empty2 ;
	ImageIcon pellet ;
	ImageIcon enemy_pink ;
	ImageIcon lifeImg ;
	pac avatar;
	blinky redmonster;
	inky bluemonster;
	clyde orangemonster;
	pinkey pinkmonster;
	Thread av;
	Thread t ;
	Thread t2 ;
	Thread t3 ;
	Thread t4 ;
	public field(JFrame frame) {	
		this.frame=frame;
		this.panel = new JPanel();
		this.panel.setPreferredSize(new Dimension(1000, 600));
		this.panel.setBackground(Color.black);
		this.panel.setLayout(new GridLayout(f.length,f[0].length));
   		frame.requestFocus();
   		avatar=new pac(13,19,this);
		 av = new Thread(avatar);
   		redmonster=new blinky(avatar,this,2,1);
   		 t = new Thread(redmonster);
   		bluemonster=new inky(avatar,this,13,1);
   		 t2 = new Thread(bluemonster);
		orangemonster=new clyde(avatar,this,2,19); 
		 t3 = new Thread(orangemonster);
		pinkmonster=new pinkey(avatar,this,3,10);
		 t4 = new Thread(pinkmonster);
   		setemptylocations();
   		setmap();
		
		
	}
	public void startgame() {
		av.start();
		t.start();
		t2.start();
		t3.start();
		t4.start();
	}
	public void setemptylocations() {
		int map_x=0,map_y=0,size_x=15,size_y=21;
		this.maplocation=new int [size_x][size_y];
		for(map_x=0;map_x<size_x;map_x++) {
			for(map_y=0;map_y<size_y;map_y++) {
				this.maplocation[map_x][map_y] = 1;
			}
		}
		
			for(map_y=0;map_y<size_y;map_y++) {
				this.maplocation[0][map_y] = 2;
			
		}
			for(map_y=0;map_y<size_y;map_y++) {
				this.maplocation[1][map_y] = 0;
				this.maplocation[14][map_y] = 0;
			
		}
			for(map_x=1;map_x<size_x-1;map_x++) {
				this.maplocation[map_x][0] = 0;
				this.maplocation[map_x][20] = 0;
			
		}
			//placing walls
		this.maplocation[7][1] = 0;this.maplocation[2][2] = 0;this.maplocation[4][2] = 0;
		this.maplocation[5][2] = 0;this.maplocation[9][2] = 0;this.maplocation[10][2] = 0;
		this.maplocation[12][2] = 0;this.maplocation[7][3] = 0;this.maplocation[2][4] = 0;
		this.maplocation[4][4] = 0;this.maplocation[12][4] = 0;this.maplocation[10][4] = 0;
		this.maplocation[6][4] = 0;this.maplocation[7][4] = 0;this.maplocation[8][4] = 0;
		this.maplocation[7][5] = 0;this.maplocation[10][5] = 0;this.maplocation[4][5] = 0;
		this.maplocation[2][6] = 0;this.maplocation[4][6] = 0;this.maplocation[5][6] = 0;
		this.maplocation[9][6] = 0;this.maplocation[10][6] = 0;this.maplocation[12][6] = 0;
		this.maplocation[13][6] = 0;this.maplocation[4][8] = 0;this.maplocation[10][8] = 0;
		this.maplocation[4][9] = 0;this.maplocation[10][9] = 0;this.maplocation[4][10] = 0;
		this.maplocation[10][10] = 0;this.maplocation[4][11] = 0;this.maplocation[10][11] = 0;
		this.maplocation[4][12] = 0;this.maplocation[10][12] = 0;this.maplocation[3][8] = 0;
		this.maplocation[11][8] = 0;this.maplocation[3][12] = 0;this.maplocation[13][8] = 0;
		this.maplocation[13][10] = 0;this.maplocation[12][10] = 0;this.maplocation[12][11] = 0;
		this.maplocation[12][12] = 0;this.maplocation[6][10] = 0;this.maplocation[7][10] = 0;
		this.maplocation[8][10] = 0;this.maplocation[6][8] = 0;this.maplocation[7][8] = 0;
		this.maplocation[8][8] = 0;this.maplocation[6][12] = 0;this.maplocation[7][12] = 0;
		this.maplocation[8][12] = 0;this.maplocation[7][19] = 0;this.maplocation[2][18] = 0;
		this.maplocation[4][18] = 0;this.maplocation[5][18] = 0;this.maplocation[9][18] = 0;
		this.maplocation[10][18] = 0;this.maplocation[12][18] = 0;this.maplocation[7][17] = 0;
		this.maplocation[2][16] = 0;this.maplocation[4][16] = 0;this.maplocation[12][16] = 0;
		this.maplocation[10][16] = 0;this.maplocation[6][16] = 0;this.maplocation[7][16] = 0;
		this.maplocation[8][16] = 0;this.maplocation[7][15] = 0;this.maplocation[10][15] = 0;
		this.maplocation[4][15] = 0;this.maplocation[2][14] = 0;this.maplocation[4][14] = 0;
		this.maplocation[5][14] = 0;this.maplocation[9][14] = 0;this.maplocation[10][14] = 0;
		this.maplocation[12][14] = 0;this.maplocation[13][14] = 0;

		//placing life
		this.maplocation[0][18] = 9;this.maplocation[0][19] = 9;this.maplocation[0][20] = 9;
		for(int i=0;i<f.length;i++) {
			for(int j=0;j<f[0].length;j++) {
				f[i][j] = new JLabel();
			}
		}
	}
	public void setmap() {
		this.pelletnumber=4;
		wall = new ImageIcon("wall.png");
		empty = new ImageIcon("empty.png");
		empty2 = new ImageIcon("empty.png");
		pellet = new ImageIcon("pellet.png");
		enemy_pink = new ImageIcon("pinkenemy.png");
		lifeImg = new ImageIcon("life.png");
		avatar.pac_x=13;avatar.pac_y=19;
		this.maplocation[avatar.pac_x][avatar.pac_y] = 3;
		redmonster.monster_x=2;redmonster.monster_y=1;
		this.maplocation[redmonster.monster_x][redmonster.monster_y] = 5;	    
		bluemonster.monster_x=13;bluemonster.monster_y=1;
		this.maplocation[bluemonster.monster_x][bluemonster.monster_y] = 6;
		orangemonster.monster_x=2;orangemonster.monster_y=19;
		this.maplocation[orangemonster.monster_x][orangemonster.monster_y] = 7;
		pinkmonster.monster_x=3;pinkmonster.monster_y=10;
		this.maplocation[pinkmonster.monster_x][pinkmonster.monster_y] = 8;
		for(int i=0; i<f.length; i++) {
  			for(int j=0; j<f[0].length; j++) {
  				
  				if(this.maplocation[i][j]==0) 
  				f[i][j].setIcon(wall);
  				
  				else if(this.maplocation[i][j] == 2)
  					f[i][j].setIcon(empty);
  				else if(this.maplocation[i][j] == 3)
  					f[i][j].setIcon(avatar.pacmanleft);
  				else if(this.maplocation[i][j]==4) 
  					f[i][j].setIcon(empty2);
  				else if(this.maplocation[i][j]==5) 
  					f[i][j].setIcon(redmonster.enemy);
  				if(this.maplocation[i][j]==6)
  					f[i][j].setIcon(bluemonster.enemy);
  				if(this.maplocation[i][j]==7)
  					f[i][j].setIcon(orangemonster.enemy);					
  				else if(this.maplocation[i][j]==8)
  					f[i][j].setIcon(pinkmonster.enemy);
  				else if(this.maplocation[i][j]==9)
  					f[i][j].setIcon(lifeImg);
  				else if(this.maplocation[i][j] == 1) {
  					f[i][j].setIcon(pellet);
  					this.pelletnumber++;
  					}
  				
  				this.panel.add(f[i][j]);
  				
  				
  			}
  		}
		this.frame.add(panel);
		keyclick key=new keyclick(avatar);
		this.frame.addKeyListener(key);
		
	}
	
	
	

}
